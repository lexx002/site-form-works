from django import forms

from .widgets import AjaxInputWidget
from .models import City


class SearchTicket(forms.Form):
    # Добавьте здесь поля, описанные в задании
    pass
